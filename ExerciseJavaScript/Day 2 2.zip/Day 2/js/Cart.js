var products = [
  {
    id: 1,
    name: "abc",
    img: './img/anh1.jpg',
    price: 165,
    description: "lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor incididunt t labore et dolore magna",
  },
  {
    id: 2,
    name: "abc",
    img: './img/anh1.jpg',
    price: 165,
    description: "lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor incididunt t labore et dolore magna",
  },
  {
    id: 3,
    name: "abc",
    img: './img/anh1.jpg',
    price: 165,
    description: "lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor incididunt t labore et dolore magna",
  },
]
var getItem = function (products) {
  var div1 = document.createElement('div');
  div1.innerHTML = "my <b>new</b> skill - <large>DOM maniuplation!</large>";
  // set style
  div1.style.color = 'red';
  // better to use CSS though - just set class
  div1.setAttribute('class', 'content'); // and make sure myclass has some styles in css
  document.body.appendChild(div1);
  
  // var render = document.getElementById("js-list-product");
  // var result = products.map((products, index) => {
  //   return '<div class="content"> <img src="' + products.img + '" class="img-100" alt="" />' + ' <div class="content_item"> <h3>' + products.name + '</h3>' + '<p>' + products.description + '</p>' + '</div>  <img src="./img/muiten.jpg" alt="" /></div>';
  // });
  // render.innerHTML = result;
  // return render;
}

window.onload = getItem(products);