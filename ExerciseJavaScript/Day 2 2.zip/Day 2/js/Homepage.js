var products = [
  {
    id: 1,
    name: "abc",
    img: './img/anh1.jpg',
    price: 165,
    description: "lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor incididunt t labore et dolore magna",
  },
  {
    id: 2,
    name: "cd",
    img: './img/anh1.jpg',
    price: 165,
    description: "lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor incididunt t labore et dolore magna",
  },
  {
    id: 3,
    name: "ef",
    img: './img/anh1.jpg',
    price: 165,
    description: "lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor incididunt t labore et dolore magna",
  },
]

products.forEach(getItem);

function getItem(item, index) {
  var render = document.getElementById("js-list-product");
  //style div parent
  var div1 = document.createElement('div');
  div1.setAttribute('class', 'content'); // and make sure myclass has some styles in css
  //style img
  var img = document.createElement('img');
  img.setAttribute('src', './img/anh1.jpg')
  //style div-content
  var div2 = document.createElement('div');
  div2.setAttribute('class', 'content_item');
  var h3 = document.createElement('h3');
  h3.innerHTML = item.name;
  var p = document.createElement('p');
  p.innerHTML = item.description;
  //button
  var button = document.createElement('button');
  button.setAttribute('class', 'js-button-addtocart');
  button.innerHTML = 'Add to Cart';
  //struce content
  div2.appendChild(h3);
  div2.appendChild(p);
  div1.appendChild(img);
  div1.appendChild(div2);
  div1.appendChild(button);
  render.appendChild(div1);
}
function addCart(item) {
  console.log(item)
  var count = 1;
  var cart = [
    id=item.id,
    count=count,
    price=item.price,
    name=item.name
  ];
  // item.disabled = true;
  console.log(cart)
  localStorage.setItem("CART", JSON.stringify(cart));
}



