var products = [
  {
    id: 1,
    name: "abc",
    img: './img/anh1.jpg',
    price: 165,
    description: "lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor incididunt t labore et dolore magna",
  },
  {
    id: 2,
    name: "abc",
    img: './img/anh1.jpg',
    price: 165,
    description: "lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor incididunt t labore et dolore magna",
  },
  {
    id: 3,
    name: "abc",
    img: './img/anh1.jpg',
    price: 165,
    description: "lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor incididunt t labore et dolore magna",
  },
]
products.forEach(getItem);
function myFunction(item, index) {
  document.getElementById("demo").innerHTML += index + ":" + item + "<br>"; 
}
var getItem = (products) => {
  var render=document.getElementById("js-list-product");
  var result = products.map((products, index) => {
    return  '<div class="content"> <img src="' + products.img + '" class="img-100" alt="" />' + ' <div class="content_item"> <h3>' + products.name + '</h3>' + '<p>' + products.description + '</p>' + '</div>  <img src="./img/muiten.jpg" alt="" /></div>';
  });
  render.innerHTML=result;
  return render;
}

window.onload = getItem(products);